import ctypes as C
import json
from pathlib import Path
import torch
assert torch.cuda.is_available() and torch.cuda.device_count()==1
assert 'H20' in torch.cuda.get_device_name(0) and torch.cuda.get_device_capability(0)==(9,0)
torch.cuda.set_device(0)
rows,cols=24,28672
buffer=torch.empty(rows*cols*4+512,dtype=torch.uint8,device='cuda:0')
base=buffer.data_ptr();assert base%256==0
maps=[l for l in Path('/proc/self/maps').read_text().splitlines() if 'libcuda.so' in l]
assert maps and not any('/compat/' in l or '/stubs/' in l for l in maps)
driver=C.CDLL('libcuda.so.1')
fn=driver.cuTensorMapEncodeTiled
fn.restype=C.c_int
fn.argtypes=[C.c_void_p,C.c_int,C.c_uint32,C.c_void_p,C.POINTER(C.c_uint64),C.POINTER(C.c_uint64),C.POINTER(C.c_uint32),C.POINTER(C.c_uint32),C.c_int,C.c_int,C.c_int,C.c_int]
dims=(C.c_uint64*2)(cols,rows);strides=(C.c_uint64*1)(cols*4)
box=(C.c_uint32*2)(32,16);elements=(C.c_uint32*2)(1,1)
results=[]
for dtype in (7,11): # CUDA13 headers: FLOAT32 and TFLOAT32.
 for offset in (4,256):
  descriptor=C.create_string_buffer(128+64)
  address=(C.addressof(descriptor)+63)&~63
  code=fn(address,dtype,2,base+offset,dims,strides,box,elements,0,3,3,0)
  results.append(dict(dtype_enum=dtype,offset=offset,address_mod16=(base+offset)%16,return_code=code))
assert all(r['return_code']==(1 if r['offset']==4 else 0) for r in results),results
torch.cuda.synchronize()
report=dict(scope='Single H20 CUDA driver TMA descriptor encoding only; no kernel execution, weights, Store daemon, inference or formal attempt',device=torch.cuda.get_device_name(0),uuid=str(torch.cuda.get_device_properties(0).uuid),torch_version=torch.__version__,results=results,real_driver_maps=maps)
Path('/output/result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
